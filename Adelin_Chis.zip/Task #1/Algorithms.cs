﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Week3
{
    public enum HMACs
    {
        HMACSHA1 = 0,
        HMACMD5 = 1,
        HMACSHA256 = 2,
        HMACSHA384 = 3,
        HMACSHA512 = 4
    }
}
